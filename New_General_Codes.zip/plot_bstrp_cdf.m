function [] = plot_bstrp_cdf(data,colr)  % Currently this only runs two conditions

for k=1:numel(data)
    dat{k}=data{k};
end

jj=cell(2,1);
jj{1} = 0.1.*randn(size(dat{1}));
jj{2} = 1+0.1.*randn(size(dat{2}));

rr = logspace(-2,1.5,10);
nr1 = hist(dat{1},rr);
nr2 = hist(dat{2},rr);

[c1, x1] = ecdf(dat{1});
[c2, x2] = ecdf(dat{2});

figure, 
  subplot(121), hold on
  h11=plot(jj{1},dat{1},'.','Color',colr{1},'MarkerFaceColor',colr{1});
  h12=plot(jj{2},dat{2},'.','Color',colr{2},'MarkerFaceColor',colr{2});
  a1=gca;
  set(a1,'YScale','log');
  %set(a1,'ylim',[5e-3, 1.1e1])
  set(a1,'xtick',[0 1])
  set(a1,'xticklabel',{'WT','S421D'})
  ylabel('Dispersion, \sigma (\mum)')
  set(gca,'LineWidth',2);
  set(gca,'FontSize',24);
  set(gca, 'FontName', 'Arial');
  set(gca,'XColor',[0 0 0],'YColor',[0 0 0]);
  xlim([-1 2])
  ylim([.5 1.5]);
  box on;

  subplot(122), hold on
  %h21=plot(cumsum(nr1./sum(nr1)),rr,'-','linewidth',2);
  %h22=plot(cumnr2./sum(nr2),rr,'-','linewidth',2);
  h21 = plot(c1, x1, '-','linewidth',2,'Color',colr{1});
  h22 = plot(c2, x2, '-','linewidth',2,'Color',colr{2});
  a2=gca;
  set(a2,'yscale','log')
  %set(a2,'ylim',[5e-3, 1.1e1])
  xlabel('CDF')
  set(gca,'LineWidth',2);
  set(gca,'FontSize',24);
  set(gca, 'FontName', 'Arial');
  set(gca,'XColor',[0 0 0],'YColor',[0 0 0]);
  xlim([-1 2])
  ylim([.5 1.5]);
  box on;