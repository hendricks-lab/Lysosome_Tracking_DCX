%% Abdullah R. Chaudhary
%% McGill University - 06/01/2019
%% PLEASE DON'T SHARE WITHOUT PERMISSION

function [] = publication_fig(select_folder,call_directory,direct_edit)

if select_folder==1||isempty(call_directory)==1||isempty(direct_edit)==1
file = uigetfile('*.fig','*.m','Select One or More Files','MultiSelect', 'on');
    if ~iscell(file)
        file={file};
    else
    end
    
elseif call_directory==1||isempty(select_folder)==1||isempty(direct_edit)==1
    inp=input('Input the folder directory that has all your figures: ','s');
    addpath(inp);
    fls=dir('*.fig');
    for j=1:numel(fls)
        file{j}=fls(j).name;
    end
    
elseif direct_edit==1||isempty(select_folder)==1||isempty(call_directory)==1
    axisHandle = gca; 
    set(findall(gca, 'Type', 'Line'),'LineWidth',2);
    set(gca,'LineWidth',2);
    set(gca,'FontSize',24);
    set(gca, 'FontName', 'Arial');
    set(gca,'XColor',[0 0 0],'YColor',[0 0 0]);
    set(gca,'Box','on');
  
%     try
%     set(gca,'MarkerSize',8);
%     set(gca,'BarWidth',1);
%     
%     catch
%     end
    pbaspect([1 1 1])
    
    %saveas(gca,sprintf('updated_Figure%d'),'fig');    % You can change fig to pdf or svg
else
    DISP('Error!');
end

if select_folder==1||call_directory==1
for k=1:numel(file)
    openfig(file{k});
    axisHandle = gca; 
    set(findall(gca, 'Type', 'Line'),'LineWidth',2);
    set(gca,'LineWidth',2);
    set(gca,'FontSize',14);
    set(gca, 'FontName', 'Arial');
    set(gca,'XColor',[0 0 0],'YColor',[0 0 0]);
    set(gca,'Box','on');
  
%     try
%     set(gca,'MarkerSize',8);
%     set(gca,'BarWidth',5);
%     
%     catch
%     end
    pbaspect([2 1 1])
    
    %saveas(gca,sprintf('updated_Figure%d',k),'fig');    % You can change fig to pdf or svg   
end
else
end



