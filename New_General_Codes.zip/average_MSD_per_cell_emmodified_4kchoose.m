function [timek2,msd2] = average_MSD_per_cell_emmodified_4kchoose(res1,col1,k_choose)

alph=[];

for j=1:numel(res1)
    dat1=res1{j};
    msd1(j,:)=res1{j}.msd;
    timek1(j,:)=res1{j}.timek;
    alph=[alph,res1{j}.slp];
end

for k=1:numel(msd1(1,:))
    msd2(k,:)=mean(msd1(:,k));
    sem(k,:)=std(msd1(:,k))./sqrt(numel(msd1(:,k)));
    timek2(k,:)=mean(timek1(:,k));
end

% for m=1:numel(timek1(:,1))
%     figure(2), 
%     hold on,
%     h2a=plot(timek1(m,:),msd1(m,:),'-','Color',col2,'LineWidth',1);
%     hold on,
%     h2a.Color(4)=0.3;
%     xlabel('Time interval (sec)'); ylabel('MSD (\mum^2)');
%     publication_fig(0,0,1);
% end

ltk2=log10(timek2);
msdk2=log10(msd2);

figure, hold on,
ub=msd2+sem;
lb=msd2-sem;
x_err=[timek2,fliplr(timek2)];
lb_to_ub= [ub, fliplr(lb)];
fill(x_err,lb_to_ub,col1, 'FaceAlpha', 0.5);
plot(timek2,msd2,'Color',col1); 
% hold on,
% errorbar(timek2,msd2,sem,'Color',col1,'LineWidth',2);
xlabel('Time'); ylabel('MSD');
publication_fig(0,0,1);

figure, hold on, %alpha plot
h1=notBoxPlot(alph,k_choose,'style','line');
set(h1.data,'MarkerFaceColor',col1,'MarkerEdgeColor',col1);
set(gca,'Ygrid','on');
xlabel(''); ylabel('\alpha');
xlim([-1 5]);
set(gca,'xticklabel',{[]})
publication_fig(0,0,1)

