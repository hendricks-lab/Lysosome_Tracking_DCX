%% Bootstrap Run Length Function - Zhu and Emily
function[curravg] = bootstrap_ep_v1(proc_plus_run_ctrl,proc_plus_run_s421d, proc_minus_run_ctrl,proc_minus_run_s421d, nsamp)
for N=1:nsamp
    for idx=1:min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)]);
    randi_Num=randi(min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)])); %generate a random list of numbers from 1 to the number of elements in the variable with replacement
    proc_run_plus_tmp(idx)=proc_plus_run_ctrl(randi_Num);%using the generated random numbers to sample the data
    randi_Num
    %     if N==1
%         preavg(N)=mle(proc_run_plus_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
%     else
    curravg(N)=mle(proc_run_plus_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
    %avgrl=vertcat(preavg(N),curravg(N));
%     avgrl=[preavg;curravg];
%     preavg=curravg;
    proc_run_plus_tmp=[];
    end
    if N==nsamp
    table_run_lyso_sample=table(curravg(N));
    writetable(table_run_lyso_sample,'wt_lysosome_runs.xlsx',"FileType","spreadsheet");
    end
end
end

%     for index=1:min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)])
%         randi_Num=randi(min(numel(proc_plus_run_ctrl), numel(proc_plus_run_s421d)) && min(numel(proc_minus_run_ctrl), numel(proc_minus_run_s421d))); %generate a random list of numbers from 1 to the number of elements in the variable with replacement
%         proc_run_plus_s421d_tmp(index)=proc_plus_run_s421d(randi_Num);%using the generated random numbers to sample the data
%     if N==1
%         preavg_s421d=mle(proc_run_plus_s421d_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
%     else
%     curravg_s421d=mle(proc_run_plus_s421d_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
%     %avgrl_s421d(N)=vertcat(preavg_s421d,curravg_s421d);
%     avgrl_s421d=[preavg_s421d;curravg_s421d];
%     preavg_s421d=curravg_s421d;
%     proc_run_plus_s421d_tmp=[];
%     end
%     if N==nsamp
%     table_run_lyso_sample_s421d=table(avgrl_s421d);
%     writetable(table_run_lyso_sample_s421d,'s421d_lysosome_runs.xlsx',"FileType","spreadsheet");
%     end
%     end
    
    
%     for index=1:min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)])
%         randi_Num=randi(min(numel(proc_plus_run_ctrl), numel(proc_plus_run_s421d)) && min(numel(proc_minus_run_ctrl), numel(proc_minus_run_s421d))); %generate a random list of numbers from 1 to the number of elements in the variable with replacement
%         proc_run_plus_s421d_tmp(index)=proc_plus_run_s421d(randi_Num);%using the generated random numbers to sample the data
%     end
%     avgrl_s421d(N)=mle(proc_run_plus_s421d_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
%     proc_run_plus_s421d_tmp=[];
%     
%     for index=1:min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)])
%         randi_Num=randi(min(numel(proc_plus_run_ctrl), numel(proc_plus_run_s421d)) && min(numel(proc_minus_run_ctrl), numel(proc_minus_run_s421d))); %generate a random list of numbers from 1 to the number of elements in the variable with replacement
%         proc_run_minus_ctrl_tmp(index)=-1*proc_minus_run_ctrl(randi_Num);%using the generated random numbers to sample the data
%     end
%     
%     avgrl_ctrl(N)=mle(proc_run_minus_ctrl_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
%     
%     proc_run_minus_ctrl_tmp=[];
%     
%     for index=1:min([numel(proc_plus_run_ctrl); numel(proc_plus_run_s421d); numel(proc_minus_run_ctrl); numel(proc_minus_run_s421d)])
%         randi_Num=randi(min(numel(proc_plus_run_ctrl), numel(proc_plus_run_s421d)) && min(numel(proc_minus_run_ctrl), numel(proc_minus_run_s421d))); %generate a random list of numbers from 1 to the number of elements in the variable with replacement
%         proc_run_minus_s421d_tmp(index)=-1*proc_minus_run_s421d(randi_Num);%using the generated random numbers to sample the data
%     end
%     
%     avgrl_s421d_minus(N)=mle(proc_run_minus_s421d_tmp,'distribution','exp');%taking the average of the sampled displacement values each iteration of the loop
%     
%     proc_run_minus_s421d_tmp=[];
% end
%     table_run_lyso_sample=table(avgrl,avgrl_s421d, avgrl_ctrl,avgrl_s421d_minus);
%     table_run_lyso_sample=table(avgrl,avgrl_s421d); %avgrl_ctrl,avgrl_s421d_minus);
%     writetable(table_run_lyso_sample,'lysosome_runs.xlsx',"FileType","spreadsheet");
    %save('lysosome_runs.mat', 'table_run_lyso_sample');

% end