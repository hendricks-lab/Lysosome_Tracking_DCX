u = cmu.units;


a = u.degC(25) % stored in K

u.degC2F(0)  % no units on output

u.degF(32)