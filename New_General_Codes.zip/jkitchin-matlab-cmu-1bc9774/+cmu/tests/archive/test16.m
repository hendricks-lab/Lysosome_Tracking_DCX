clear all;
u = cmu.units;
a = 4*u.lb*u.lb
a = 4*u.lb*u.lb/u.lb
a = 4*u.lb^2/u.lb
