function [Rg] = func_Rg_Linda_v2(xk,yk)

mean_x=mean(xk); % average x position in trajectory
mean_y=mean(yk); %average y position in trajectory

a=(xk-mean_x).^2; % square of each (x position-mean)
b=(yk-mean_y).^2; % square of each (y position-mean)
c=a+b; % Adding together the squared of each position-mean position in x and y

Rg=sqrt((1./numel(xk)).*sum(c)); %taking the square root of the mean
