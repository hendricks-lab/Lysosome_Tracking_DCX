function [res] = analyze_run_length_reversals_v3(time_in,position_in,min_lr,plt,k_choose)

% Its 0.03 for Early Endosomes and lysosomes
%% Savitsky Golay smoothing
span=9;    % 10 is good, 25 is good as well
pwr=6;      % 1 is good, 2 is good

position_smooth=smooth(position_in,span,'sgolay',pwr);
timek=time_in;

if plt==1
figure(989.*k_choose),hold on,
plot(position_in)
hold on, 
plot(position_smooth)
ylim([-6 6])
hold off
else
end
lr_ind=findinflections(0,position_smooth);
lr_1=position_smooth(lr_ind);
ttim=time_in(lr_ind);
run_bw_reversal=diff(lr_1);
timek_bw_reversal = diff(ttim);
rev_rate=numel(lr_ind)./(timek(end)-timek(1));

proc_run=run_bw_reversal(find(abs(run_bw_reversal)>=min_lr));
diff_run=run_bw_reversal(find(0.03<=abs(run_bw_reversal)<min_lr));
stat_run=run_bw_reversal(find(abs(run_bw_reversal)<0.01));

proc_time=timek_bw_reversal(find(abs(run_bw_reversal)>=min_lr));
diff_time=timek_bw_reversal(find(0.03<=abs(run_bw_reversal)<min_lr));
stat_time=timek_bw_reversal(find(abs(run_bw_reversal)<0.01));

proc_plus_runs=proc_run(find(proc_run>0));
proc_minus_runs=proc_run(find(proc_run<0));
proc_plus_times=proc_time(find(proc_run>0));
proc_minus_times=proc_time(find(proc_run<0));

res.run_bw_rev=run_bw_reversal;
res.time_bw_rev=timek_bw_reversal;
res.reversal_rate=rev_rate;
res.proc_run=proc_run;
res.diff_run=diff_run;
res.stat_run=stat_run;
res.proc_time=proc_time;
res.diff_time=diff_time;
res.stat_time=stat_time;
res.avg_velplus=mean(proc_plus_runs./proc_plus_times);
res.avg_velminus=mean(proc_minus_runs./proc_minus_times);
res.avg_lrplus=mean(proc_plus_runs);
res.avg_lrminus=mean(proc_minus_runs);


