function [deltat, msdpts, sem, log_deltat, log_msdpts, alpha1, alpha2, DiffCoef] = MSD_2d (x, y, DT, k_choose)
% msd - calculates the msd curve for 2-D dissusion 
%   x: vector of x positions
%   y: vector of y positions

% modified from
% http://stackoverflow.com/questions/7489048/calculating-mean-squared-displacement-msd-with-matlab
tau = DT; % s time between trajectory points
data = sqrt(x.^2 + y.^2);
nData = length(data); %# number of data points
numberOfDeltaT = 300;%floor(nData/20); %# for MSD, dt should be up to 1/4 of number of data points

% Q for Abdullah, why do we need these different sized matrices of zeros of
% size N by 1?
%Idea: maybe it's setting the size of the matrix that needs to be filled
%in.
sem = zeros(numberOfDeltaT, 1); 
deltat = zeros(numberOfDeltaT, 1); 
msdpts = zeros(numberOfDeltaT, 1); 
sqdisp = zeros(numberOfDeltaT, 1); 

%# calculate msd for all deltaT's

for dt = 1:numberOfDeltaT; 
   sqdisp = (data(1+dt:end) - data(1:end-dt)).^2;
   deltat(dt) = dt * tau;
   sem(dt) = std(sqdisp) / sqrt(length(msdpts) / dt);
   msdpts(dt) = mean(sqdisp); 
end
    dp=polyfit(deltat,msdpts,1);
    DiffCoef=dp(1)./4;
    log_deltat=log10(deltat);
    log_msdpts=log10(msdpts);
    [slopechange] = ischange(log_msdpts,'linear','MaxNumChanges',5);
    changepoint=find(slopechange==1);
    numchgs=numel(changepoint);
    if numchgs >= 4
        slope1=polyfit(log_deltat(changepoint(1):changepoint(2)), log_msdpts(changepoint(1):changepoint(2)), 1);
        slope2=polyfit(log_deltat(changepoint(3):changepoint(4)), log_msdpts(changepoint(3):changepoint(4)), 1); 
        alpha1=slope1(1);
        alpha2=slope2(1);
    else
        slope1=polyfit(log_deltat(changepoint(1):changepoint(2)), log_msdpts(changepoint(1):changepoint(2)), 1);
        slope2=polyfit(log_deltat(changepoint(numchgs):300), log_msdpts(changepoint(numchgs):300), 1); 
        alpha1=slope1(1);
        alpha2=slope2(1);
    end
    %figure(k_choose.*1000), hold on, plot(deltat, msdpts);
end