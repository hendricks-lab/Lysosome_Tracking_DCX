%% Abdullah R. Chaudhary
%% McGill University - 06/01/2019
%% PLEASE DON'T SHARE WITHOUT PERMISSION

% Input - xData, the maximum number of fits, and the color of your histogram

function[min_norm2]=gmm_func(steps_size,mmdist,kcol)

options=statset('Display','final','MaxIter',1000,'TolX',1e-8,'robust','on');
bin_size=min(steps_size):max(steps_size);
%for in=1:numel(steps_size)
steps_all=steps_size;  
for kdist=1:mmdist
    fitt=fitgmdist(steps_size,kdist,'Options',options,'Start','randSample');%,'Regularize', 1e-5);
    fitt1{kdist}=fitt;
    BIC_vals{kdist}=fitt1{kdist}.BIC;
    mu_vals{kdist}=fitt1{kdist}.mu;
    mu_vals_SD{kdist}=fitt1{kdist}.Sigma;
end 
%end

values_BIC=cell2mat(BIC_vals);
[min_val,min_ind]=min(values_BIC);
mu_min1=mu_vals{min_ind};
sig_min1=mu_vals_SD{min_ind};

[min_mu,min_mu_ind]=min(mu_min1);
min_sig=sig_min1(min_mu_ind);

for kdd1=1:min_ind
    sig_ft1=fitt1{min_ind}.Sigma(kdd1);
    sig_ft=sig_ft1(:);
    pfc{kdd1}=mvnpdf(bin_size',fitt1{min_ind}.mu(kdd1)',sig_ft(:));
    Pcomps{kdd1}=fitt1{min_ind}.PComponents(kdd1);
    min_norm1=[fitt1{min_ind}.mu(kdd1).*fitt1{min_ind}.PComponents(kdd1)]./kdd1;
    min_norm2{kdd1}=min_norm1;
end

figure
hold on,
plot(values_BIC,'.','Color',kcol,'MarkerSize',30);
hold on,
plot(values_BIC,'--','Color',kcol,'LineWidth',2);
xlabel('Number of components'); ylabel('BIC');
set(gca,'FontSize',25);
set(gca,'LineWidth',2);
set(gca,'XTick',[1 2 3 4 5 6 7],'XTickLabel',{'1','2','3','4','5','6','7'});
xlim([0 8]);
box on;
set(gca,'Xgrid','on');
pbaspect([1 1 1])

%% Gaussian fits - Plots
figure,
hold on,
steps_bins=hist(steps_all,bin_size);
bar(bin_size,steps_bins,'FaceColor',kcol,'edgecolor',kcol,'Barwidth',0.8);
fit_stepss=pdf(fitt1{min_ind},bin_size');
Cpf=1.*(max(steps_bins))./max(fit_stepss);
for kdd=1:min_ind;%1:kdist
hold on,
plot(bin_size,pfc{kdd}.*Cpf.*(Pcomps{kdd}),'k','LineWidth',2);
hold on,
xlabel('Step Size (a.u.)'); ylabel('Fraction of steps');
set(gca,'fontSize',24);
set(gca,'Ygrid','on');
set(gca,'LineWidth',2);
box on;
pbaspect([1 1 1])
end
