% Output the position values
% Abdullah R. Chaudhary (McGill University) - 07/08/2019

function [res] = calculate_euclid_distance(xk,yk,xk_center,yk_center,plt)
dist_init=zeros(1,numel(xk));

if range(yk)>range(xk)
    xk_old=xk;
    yk_old=yk;
    yk1=xk_old;
    xk1=yk_old;
elseif range(xk)>range(yk)
    xk1=xk;
    yk1=yk;
else
    xk1=xk;
    yk1=yk;
end

clear xk yk;
xk=xk1; yk=yk1;
[mt_coords_x,ind_xk]=unique(xk);
mt_coords_y1=polyfit(mt_coords_x,yk(ind_xk),1);
mt_coords_y=polyval(mt_coords_y1,mt_coords_x);

mt_coords_x=mt_coords_x;
mt_coords_y=mt_coords_y;

% Distance from the center of the cell:
dist_cent_start=sqrt((xk_center-xk1(1)).^2 + (yk_center-yk1(1)).^2);
dist_cent_end=sqrt((xk_center-xk1(end)).^2 + (yk_center-yk1(end)).^2);

position=cumsum(dist_init);

if dist_cent_start>dist_cent_end % Minus-ended motion
    mt_coords=[flipud(mt_coords_x),flipud(mt_coords_y)];
elseif dist_cent_start<dist_cent_end % Plus-ended motion
    mt_coords=[mt_coords_x,mt_coords_y];
else
    mt_coords=[];
end

if isempty(mt_coords)~=1
    %% Project displacement
    dat_vector=[0,0;diff(xk),diff(yk)];
    % project displacement along polynomail fit to trajectory
    dat_vector=[0,0;diff(xk),diff(yk)];
    mt_vector=[0,0;diff(mt_coords)];
    fit_vector(:,1)=interp1(mt_coords(:,1),mt_vector(:,1),xk,'pchip');
    fit_vector(:,2)=interp1(mt_coords(:,1),mt_vector(:,2),xk,'pchip');
    %p_traj=polyfit(mt_coords(:,1),mt_coords(:,2),2);
    %fit_vector=[ones(size(xk)),2*p_traj(1).*xk + p_traj(2)];
    fit_norm=repmat(sqrt(sum(fit_vector.^2,2)),1,2);
    fit_vector_norm=fit_vector./fit_norm; %normalize
    delp=zeros(1,numel(xk));
    delp_off=zeros(1,numel(xk));
    for kv=1:numel(xk),
        delp(kv)=dat_vector(kv,:)*fit_vector_norm(kv,:)'; %displacement projected onto MT axis
        delp_off(kv)=dat_vector(kv,:)*(fit_vector_norm(kv,:)*[0,1;-1,0])'; %disp. ... orthogonal to MT axis
    end

    delp=delp(~isnan(delp));
    delp_off=delp_off(~isnan(delp_off));

    position=cumsum(delp);
    position_off=cumsum(delp_off);
else
    position=[];
    position_off=[];
end

res.position=position;
